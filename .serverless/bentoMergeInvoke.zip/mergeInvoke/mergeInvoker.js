const AWS = require("aws-sdk");
const lambda = new AWS.Lambda({
    region: "us-east-1"
});
const mergeFunction = process.env.mergeLamdaArn;

exports.mergeInvoke = async (event) => {
    const eventRecord = event.Records[0];
    const dbEventType = eventRecord.eventName;

    if (dbEventType !== "MODIFY") {
        console.log(`\nFrom 'mergeInvoke'(func):[NOT A MODIFY] -DBEntryType: ${dbEventType}\nnot a modification of an entry in the Jobs table.`);
        return;
    }

    const entryInfo = eventRecord.dynamodb.NewImage;

    if (entryInfo.status.S !== "pending") {
        console.log(`\nFrom 'mergeInvoke'(func):[NO INVOCATION REQUEST] \njobs table was updated, not in such a way so as to invoke the merge function.`);
        return;
    }

    const jobID = entryInfo.id.S;
    const finishedTasks = entryInfo.finishedTasks.N;
    const totalTasks = entryInfo.totalTasks.N;

    const mergeParams = {
        FunctionName: mergeFunction,
        InvocationType: "Event",
        Payload: JSON.stringify({ jobId: jobID }),
        LogType: 'None',
        ClientContext: 'MergeInvokerFunction',
    };

    if (finishedTasks === totalTasks) {
        console.log(`\nFrom 'mergeInvoke'(func):[EQUAL TASKS] \n'merge'(func) should be invoked on this condition`);

        /* console.log('Attempting merge invoke...')

        await lambda.invoke(mergeParams, (err, data) => {
            if (err) {
                console.error(JSON.stringify(err));
            } else {
                console.log(data);
            }
        }).promise()
    } */
    };

    /* event = {
        Records: [
            {
                eventID: 'c73ebcca7683438372df2cb14c3657a7',
                eventName: 'INSERT',
                eventVersion: '1.1',
                eventSource: 'aws:dynamodb',
                awsRegion: 'us-east-1',
                dynamodb: [Object],
                eventSourceARN: 'arn:aws:dynamodb:us-east-1:433395856193:table/Jobs/stream/2020-03-17T02:09:59.079'
            }
        ]
    
    eventRecord: {
            eventID: '27f57feffca61f055afe7fd6845919bd',
            eventName: 'INSERT',
            eventVersion: '1.1',
            eventSource: 'aws:dynamodb',
            awsRegion: 'us-east-1',
            dynamodb: {
                ApproximateCreationDateTime: 1584423685,
                Keys: { id: [Object] },
                NewImage: { id: [Object] },
                SequenceNumber: '10269100000000012804892658',
                SizeBytes: 10,
                StreamViewType: 'NEW_IMAGE'
            },
            eventSourceARN: 'arn:aws:dynamodb:us-east-1:433395856193:table/Jobs/stream/2020-03-17T02:09:59.079'
        }
    
    entryInfo: {
        createdAt: { S: '1584420243510' },
        completedAt: { NULL: true },
        filename: { S: 'invokeTest1' },
        finishedTasks: { N: '10' },
        outputType: { S: '.mp4' },
        inputType: { S: '.ogv' },
        id: { S: '1584420220767' },
        totalTasks: { N: '14' },
        status: { S: 'pending' } */
}